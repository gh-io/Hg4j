"""
cpl_fields_mod.py
Automatically generated.
"""
