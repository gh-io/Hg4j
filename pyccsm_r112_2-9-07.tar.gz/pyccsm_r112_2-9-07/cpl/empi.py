try:
    import mpi
    print "Using PyMPI"

