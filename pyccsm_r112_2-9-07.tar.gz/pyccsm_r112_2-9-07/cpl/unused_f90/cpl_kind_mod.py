"""
cpl_kind_mod.py
Automatically generated.
"""
 R16 =  SHR_KIND_R16 
 R8  =  SHR_KIND_R8  
 R4  =  SHR_KIND_R4  
 RN  =  SHR_KIND_RN  
 I8  =  SHR_KIND_I8  
 I4  =  SHR_KIND_I4  
 IN  =  SHR_KIND_IN  
 CL  =  SHR_KIND_CL  
