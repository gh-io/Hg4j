#!/bin/bash
mpiexec -l -n 1 /home/steder/pyCPL/xcpl : -n 1 /home/steder/pyCPL/xatm
