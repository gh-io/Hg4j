def setup():
    global somevalue
    somevalue = 0
