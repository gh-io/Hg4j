"""
This function takes a list:

["atm","ocn","ice","lnd","cpl"] 

of components and builds an mph file of the format:

# Listing: mph_processors_map.in
PROCESSORS_MAP
BEGIN
atm
ice
lnd
ocn
cpl
END
# End Listing
"""

